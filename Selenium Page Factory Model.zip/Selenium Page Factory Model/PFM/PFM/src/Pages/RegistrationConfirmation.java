package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationConfirmation {
	public WebDriver driver; 
	@FindBy(how=How.XPATH,using="html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/p[3]/a/font/b")
	public WebElement ConfirmMsg;	
	public RegistrationConfirmation(WebDriver driver){
		this.driver = driver;
	}
}



