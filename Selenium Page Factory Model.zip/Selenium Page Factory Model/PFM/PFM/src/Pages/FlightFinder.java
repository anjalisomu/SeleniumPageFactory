package Pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


public class FlightFinder {
	public WebDriver driver; 
	@FindBy(how=How.NAME,using="tripType")
	public  WebElement OneWay;
	@FindBy(how=How.NAME,using="passCount")
	public WebElement Passengers;
	@FindBy(how=How.NAME,using="fromPort")
	public  WebElement Fromport;
	@FindBy(how=How.NAME,using="fromMonth")
	public  WebElement FromMonth;
	@FindBy(how=How.NAME,using="fromDay")
	public  WebElement FromDay;
	@FindBy(how=How.NAME,using="toPort")
	public  WebElement ToPort;
	@FindBy(how=How.NAME,using="toMonth")
	public  WebElement ToMonth;
	@FindBy(how=How.NAME,using="toDay")
	public  WebElement ToDay;
	@FindBy(how=How.NAME,using="servClass")
	public  WebElement SerClass;
	@FindBy(how=How.NAME,using="airline")
	public  WebElement Airline;
	@FindBy(how=How.NAME,using="findFlights")
	public  WebElement FindFlights;
	public FlightFinder(WebDriver driver){
		this.driver = driver;
	}
}

