package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;



public class FlightConfirmation {
	public WebDriver driver;
	@FindBy(how=How.XPATH,using="html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr[1]/td[2]/table/tbody/tr[5]/td/table/tbody/tr[1]/td/table/tbody/tr/td[1]/b/font/font/b/font[1]")
	public WebElement ConfirmMsg;

	public FlightConfirmation(WebDriver driver){
		this.driver = driver;
	}
	

}

