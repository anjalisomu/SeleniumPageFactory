package Pages;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;



public class Register {
	
	public WebDriver driver; 
	@FindBy(how=How.NAME,using="firstName")
	public WebElement FirstName;
	@FindBy(how=How.NAME,using="lastName")
	public  WebElement LastName;
	@FindBy(how=How.NAME,using="phone")
	public  WebElement Phone;
	@FindBy(how=How.NAME,using="userName")
	public  WebElement Email;
	@FindBy(how=How.NAME,using="address1")
	public  WebElement address;
	@FindBy(how=How.NAME,using="city")
	public  WebElement city;
	@FindBy(how=How.NAME,using="state")
	public  WebElement state;
	@FindBy(how=How.NAME,using="postalCode")
	public  WebElement postalcode;
	@FindBy(how=How.NAME,using="country")
	public  WebElement country;
	@FindBy(how=How.NAME,using="email")
	public  WebElement UserName;
	@FindBy(how=How.NAME,using="password")
	public  WebElement Password;
	@FindBy(how=How.NAME,using="confirmPassword")
	public  WebElement ConfirmPassword;
	@FindBy(how=How.NAME,using="register")
	public  WebElement btnSubmit;
	public Register(WebDriver driver){
		this.driver = driver;
		
	}

	
}
