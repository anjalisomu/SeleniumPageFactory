package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SelectFlight {
	public WebDriver driver; 
	@FindBy(how=How.NAME,using="outFlight")
	public  WebElement OutFlight;
	@FindBy(how=How.NAME,using="inFlight")
	public  WebElement InFlight;
	@FindBy(how=How.NAME,using="reserveFlights")
	public WebElement ReserveFlights;
	public SelectFlight(WebDriver driver){
		this.driver = driver;
	}

}
