package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Homepage {
	
    
	public WebDriver driver; 
    @FindBy(how=How.NAME,using="userName")
	public WebElement UserName;
    @FindBy(how=How.NAME,using="password")
    public  WebElement Password;
    @FindBy(how=How.NAME,using="login")
    public  WebElement SignIn;
    @FindBy(how=How.LINK_TEXT,using="REGISTER")
	public  WebElement REGLink;
    @FindBy(how=How.LINK_TEXT,using="userName")
    public  WebElement SigninLink;
	public Homepage(WebDriver driver){
		this.driver = driver;
	}

}
