package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;



public class BookFlight {
	public WebDriver driver; 
	@FindBy(how=How.NAME,using="passFirst0")
	public WebElement FirsNm;
	@FindBy(how=How.NAME,using="passLast0")
	public  WebElement LastNm;
	@FindBy(how=How.NAME,using="creditnumber")
	public  WebElement Cardnumber;
	@FindBy(how=How.NAME,using="buyFlights")
	public  WebElement BuyFlights;
	
		
	public BookFlight (WebDriver driver){
			this.driver = driver;
		}	

}
 