// File contains all application specific Methods
package Lib;
import java.io.*;
import java.util.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import Pages.BookFlight;
import Pages.FlightConfirmation;
import Pages.FlightFinder;
import Pages.Homepage;
import Pages.Register;
import Pages.RegistrationConfirmation;
import Pages.SelectFlight;
import Pages.SignOn;

public class keyWords  {
	
	public static Properties consts;
	public static CommonFunctions CF; 
	public static Register Reg;
	public static SignOn Signin ;
	public static RegistrationConfirmation RegConf;
	public static Homepage Home ;
	public static FlightFinder FF;
	public static BookFlight BF ;
	public static SelectFlight SF;
	public static FlightConfirmation FC;
	//static WebDriver driver;
	public static WebDriver driver;
	public static Xls_Reader DataDriver;
	
	
// Initialization of object
	public keyWords() throws IOException
	{
		CF = new CommonFunctions();
		
	}

// Keyword to launch the application	
	public int LaunchURL() throws IOException, InterruptedException 
	{
		consts = new Properties();
		WebElement obj;
		 FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"\\src\\Config\\Constant.properties");
		 consts.load(fs);
		 	CF.openBrowser();
		 	IntializePages();
		 //System.out.println("URL "+consts.getProperty("URL"));
		 //CF.openBrowser();
		 CF.Navigate(consts.getProperty("URL"));
		 Thread.sleep(5000);
		
		 obj= Home.UserName;
		 
		 if (obj!=null){
			// System.out.println( obj.getText());
			 return 1;
		 }
		 else{
			 return 0;
		 }
	}
// Keyword to Register the user on site	
	public int RegisterUser() throws IOException, InterruptedException 
	{
		WebElement obj;
		int i = 0;
		obj= Home.REGLink;
		if (obj!=null){
		i = CF.click(obj);
		obj=Reg.FirstName;
		if (obj!=null){
			i= CF.enterText(obj,GetKeywordFieldData("FirstName"));
			obj=Reg.LastName;
			if (obj!=null){
				i= CF.enterText(obj,GetKeywordFieldData("LastName"));
				obj=Reg.Phone;
				if (obj!=null){
					i= CF.enterText(obj,GetKeywordFieldData("Phone"));
					obj=Reg.Email;
					if (obj!=null){
						i= CF.enterText(obj,GetKeywordFieldData("Email"));
						obj=Reg.address;
						if (obj!=null){
							i= CF.enterText(obj,GetKeywordFieldData("Address"));
							obj=Reg.city;
							if (obj!=null){
								i= CF.enterText(obj,GetKeywordFieldData("City"));
								obj=Reg.postalcode;
								if (obj!=null){
									Thread.sleep(5000);
									i= CF.enterText(obj,GetKeywordFieldData("PostalCode"));
									obj=Reg.country;
									if (obj!=null){
										CF.elementHighlight(obj);
										i= CF.Select(obj,GetKeywordFieldData("Country"));
										obj=Reg.UserName;
										if (obj!=null){
											i= CF.enterText(obj,GetKeywordFieldData("UserName"));
											obj=Reg.Password;
											if (obj!=null){
												i= CF.enterText(obj,GetKeywordFieldData("Password"));
												obj=Reg.ConfirmPassword;
												if (obj!=null){
													i= CF.enterText(obj,GetKeywordFieldData("Password"));
													obj=Reg.btnSubmit;
													if (obj!=null){
														i =CF.click(obj);	
														obj=RegConf.ConfirmMsg;
														if (obj!=null)
															return i;
														else
															return  0;	
													}
												else
													return 0;
												}
											else
												return 0;
											}
										else
											return 0;
										}
									else 
										return 0;
									}
								else
									return 0;
								}	
							else
								return 0;
							}
						else	
							return 0;
						}
					else
						return 0;
					}
				else
					return 0;
				}
		}
		return 0;
	}	
	else
	return 0;
	}
return 0;
}		
	

// Keyword to Sign in the Application	
	public int SignIn() throws IOException, InterruptedException
	{  
		WebElement obj;
		
		int i=0;
		obj= Home.SigninLink;
		if (obj!=null){
			i=CF.click(obj);
			
			obj =  Signin.UserName;
			if (obj!=null){
				i=CF.enterText(obj, GetKeywordFieldData("UserName"));
				obj = Signin.Password;
				if (obj!=null){
					i= CF.enterText(obj,GetKeywordFieldData("Password"));
					obj=Signin.SignIn;
					if (obj!=null){
						i=CF.click(obj);
							obj=FF.FindFlights;
						if (obj!=null)
							return i;
						else 
							return 0;						
					}
					else
						return 0;
				}
				else
					return 0;
			}
			else
				return 0;
		}
		else
			return 0;
	}

	// Keyword to Book the Application	
		public int BookFlight() throws IOException, InterruptedException
		{  
			WebElement obj;
			int i=0;
			String OPT =  GetKeywordFieldData("TripOption");
			int opt = Way(OPT);
			i = CF.ClickRadiobtn("tripType", opt);
			obj =  FF.Passengers;
				if (obj!=null){
					i=CF.Select(obj, GetKeywordFieldData("Passengers"));
					obj = FF.Fromport;
					if (obj!=null){
						i= CF.Select(obj, GetKeywordFieldData("FromDestination"));
						obj=FF.FromMonth;
						if (obj!=null){
							i=CF.Select(obj, GetKeywordFieldData("FromMonth"));
							obj=FF.FromDay;
							if (obj!=null){
								i=CF.Select(obj, GetKeywordFieldData("FromDay"));
								obj = FF.ToPort;
								if (obj!=null){
									i= CF.Select(obj, GetKeywordFieldData("ToDestination"));
									obj=FF.ToMonth;
									if (obj!=null){
										i=CF.Select(obj, GetKeywordFieldData("ToMonth"));
										obj=FF.ToDay;
										if (obj!=null){
											i=CF.Select(obj, GetKeywordFieldData("ToDay"));
											String Class =  GetKeywordFieldData("ServiceClass");
											int intCls = BusinessClass(Class);
											i = CF.ClickRadiobtn("servClass", intCls);
											
											obj = FF.Airline;
											if (obj!=null){
												i = CF.Select(obj, GetKeywordFieldData("AirLine"));
												obj = FF.FindFlights;
												if (obj!=null){
													i = CF.click(obj);
													String DepFlight =  GetKeywordFieldData("DepartFlight");
													int intDepFlight = DepartFlight(DepFlight);
													i = CF.ClickRadiobtn("outFlight", intDepFlight);
													obj = SF.ReserveFlights;
													if (obj!=null){
														i = CF.click(obj);
														obj= BF.FirsNm;
														if (obj!=null){
															i=CF.enterText(obj, GetKeywordFieldData("FirstName"));
															obj = BF.LastNm;
															if (obj!=null){
																i=CF.enterText(obj, GetKeywordFieldData("LastName"));
																obj = BF.Cardnumber;
																if (obj!=null){
																	i=CF.enterText(obj, GetKeywordFieldData("CardNo"));
																	obj = BF.BuyFlights;
																	if (obj!=null){
																		i= CF.click(obj);
																		
																		obj = FC.ConfirmMsg;
																		if (obj!=null)																	
																			return i;
																		else
																			return 0;
																	}
																	else
																		return 0;
																	}
																else
																	return 0;
															}
															else
																return 0;
														}
														else
															return 0;
													}
													else
														return 0;
												}
												else
													return 0;
												
											}
											else
												return 0;
										}
										else
											return 0;
									}
									else
										return 0;
								}
								else
									return 0;
							}
							else
								return 0;
						}
						else 
								return 0;						
						}
						else
							return 0;
					}
					else
						return 0;
				}
			


	
	
// Keyword to close all opened browsers	
	public int CloseallBrowsers() throws IOException, InterruptedException 
	{
		CF.closeBrowser();
		 return 1;
	}
	
// Method to get Test data for a particular  field	
	public String GetKeywordFieldData(String FieldName){
		String FieldValue ="";
		String TD_BSID,TD_TSID,TD_TCID;
		DataDriver =  new Xls_Reader(System.getProperty("user.dir")+"\\src\\datatables\\Test_Data.xls");
		//System.out.println(" FieldName :"+FieldName);
		int i = DataDriver.getColumnNo("TestData", FieldName);
		//System.out.println(FieldName+" Field  is at :"+i);
		//System.out.println(" currentBSID :"+GlobalVariables.currentBSID);
		//System.out.println(" currentTSID :"+GlobalVariables.currentTSID);
		//System.out.println(" TD_TCID :"+GlobalVariables.currentTCID);
		for (GlobalVariables.Testdata_row =2;GlobalVariables.Testdata_row<= DataDriver.getRowCount("TestData");GlobalVariables.Testdata_row++){
			TD_BSID=DataDriver.getColumnValue("TestData", GlobalVariables.BS_ID, GlobalVariables.Testdata_row);
			TD_TSID=DataDriver.getColumnValue("TestData", GlobalVariables.TS_ID, GlobalVariables.Testdata_row);
			TD_TCID=DataDriver.getColumnValue("TestData", GlobalVariables.TC_ID, GlobalVariables.Testdata_row);
			//System.out.println(" TD_BSID :"+TD_BSID);
			//System.out.println(" TD_TSID :"+TD_TSID);
			//System.out.println(" TD_TCID :"+TD_TCID);
			if (TD_BSID.equals(GlobalVariables.currentBSID) && TD_TSID.equals(GlobalVariables.currentTSID) && TD_TCID.equals(GlobalVariables.currentTCID)){
				 FieldValue =DataDriver.getColumnValue("TestData", i, GlobalVariables.Testdata_row);
				  break;			
				}
			}
		return FieldValue;
	}


public int Way(String str)
{
	if (str.equalsIgnoreCase("One Way"))
		return 2;
	else
		return 1;
}

public int BusinessClass(String str)
{
	if (str.equalsIgnoreCase("Economy class"))
		return 1;
	if (str.equalsIgnoreCase("Business class"))
		return 2;
	if (str.equalsIgnoreCase("First class"))
		return 3;
	return 0;
	}

public int DepartFlight(String str)
{
	if (str.equalsIgnoreCase("Blue Skies Airlines 360"))
		return 1;
	if (str.equalsIgnoreCase("Blue Skies Airlines 361"))
		return 2;
	if (str.equalsIgnoreCase("Pangaea Airlines 362"))
		return 3;
	if (str.equalsIgnoreCase("Unified Airlines 363"))
		return 4;

	return 0;
	}
public void IntializePages(){
	Reg = new Register(GlobalVariables.driver);
	PageFactory.initElements(GlobalVariables.driver, Reg);
	Home = new Homepage(GlobalVariables.driver);
	PageFactory.initElements(GlobalVariables.driver, Home);
	Signin= new SignOn(GlobalVariables.driver);
	PageFactory.initElements(GlobalVariables.driver, Signin);
	RegConf= new RegistrationConfirmation(GlobalVariables.driver);
	PageFactory.initElements(GlobalVariables.driver, RegConf);
	FF= new FlightFinder(GlobalVariables.driver);
	PageFactory.initElements(GlobalVariables.driver, FF);
	BF= new BookFlight(GlobalVariables.driver);
	PageFactory.initElements(GlobalVariables.driver, BF);
	SF= new SelectFlight(GlobalVariables.driver);
	PageFactory.initElements(GlobalVariables.driver, SF);
	FC= new FlightConfirmation(GlobalVariables.driver);
	PageFactory.initElements(GlobalVariables.driver, FC);
}

}